SaltyMC

Documentation
SaltyMC.zip is automatically re-zipped when changes are made to the main branch (through github actions).
Re-pull then calculate the SHA1 of the newly created SaltyMC.zip.
The zip file is hosted publicly through github pages.
